//
//  PhotoCollectionViewCell.swift
//  virtualtourist
//
//  Created by Brian Hamilton on 5/7/21.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!

}
