//
//  Photos.swift
//  virtualtourist
//
//  Created by Brian Hamilton on 5/4/21.
//

import Foundation

struct Photos: Codable {
    let photos: SetOfPhotos
}
